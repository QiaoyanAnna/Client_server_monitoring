# Client_server_monitoring

## Reference
Get milliseconds:
https://stackoverflow.com/questions/3756323/how-to-get-the-current-time-in-milliseconds-from-c-in-linux [Accessed Mar.31, 2020]

Man page: 
https://www.linuxjournal.com/article/1158 [Accessed Mar 31, 2020]

## Collaborator
Zhonghao Lu
